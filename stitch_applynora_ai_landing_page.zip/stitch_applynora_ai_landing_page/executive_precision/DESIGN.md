---
name: Executive Precision
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#3130c0'
  on-tertiary: '#ffffff'
  tertiary-container: '#4b4dd8'
  on-tertiary-container: '#d9d8ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an atmosphere of effortless competence, cognitive clarity, and unwavering reliability for high-stakes career automation. The aesthetic bridges high-end enterprise SaaS with modern consumer intelligence—eschewing clinical sterility in favor of calibrated warmth, technological empowerment, and quiet confidence.

The core visual style blends **Corporate Modernism** with **Refined Glassmorphism**:
- Ultra-crisp surface boundaries characterized by delicate 1px translucent borders (`rgba(255, 255, 255, 0.6)` in light mode, `rgba(255, 255, 255, 0.08)` over deep navy).
- Ambient, multi-layered atmospheric shadows providing structural weight without visual noise.
- Kinetic responsiveness that emphasizes low-latency AI performance: silky easing curves, progressive disclosure states, and purposeful focus indicators.
- High-trust signaling through deliberate visual cadence: dense telemetry metrics offset by open, breathable workspace canvases.

## Colors

The palette leverages high-contrast tonal relationships designed for long sessions of document scanning, pipeline analysis, and tactical workflow execution.

### Color Roles & Semantics
- **Primary (`#4F46E5` / Royal Indigo):** The core interactive engine. Used for primary calls-to-action, definitive active states, progress indicators, and keyboard focus focus-rings.
- **Secondary (`#10B981` / Emerald Mint):** The validation and intelligence layer. Reserved strictly for successful submissions, AI match scores, verified ATS compliance badges, and positive progression telemetry.
- **Tertiary (`#6366F1` / Tech Violet):** The generative spark. Applied to AI-assisted prompt highlights, smart resume recommendations, and atmospheric ambient gradients.
- **Neutral Surface Hierarchy:**
  - Base canvas: `#F8FAFC` (Slate 50) creates a soft, low-glare backdrop.
  - Surface cards: `#FFFFFF` (Pure White) delivers luminous separation.
  - High-contrast containers / Navigation rail: `#0F172A` (Deep Slate Navy) anchors global tools and establishes executive weight.
  - Borders & Dividers: `#E2E8F0` (Slate 200) for standard layout lines; `rgba(99, 102, 241, 0.12)` for AI-context boundaries.

## Typography

Typography establishes an intentional cadence between dynamic display authority and clinical legibility:

- **Display & Headings (Plus Jakarta Sans):** Selected for its friendly yet modern architectural proportions. Wide apertures and clean geometric construction grant confidence to dashboard metrics and milestone banners.
- **Data, Interactive & Body (Inter):** Optimized for high-density tables, multi-page resume editors, and detailed ATS evaluation reports. Tight tracking controls ensure tall x-height forms remain legible at compact sizes.
- **Numeric & Metric Treatments:** When presenting real-time match percentages, ATS compatibility scores, or salary projections, apply tabular lining numbers (`font-variant-numeric: tabular-nums`) to prevent layout shift during updates.

## Layout & Spacing

The layout operates on a flexible 12-column responsive fluid grid structured around strict vertical baseline rhythms of 4px and 8px.

### Grid & Breakpoints
- **Desktop (≥ 1280px):** 12-column layout, `margin-lg` (3rem / 48px) outer margin, `gutter-lg` (2rem / 32px). Supports dual-pane work zones (e.g., job criteria left, live tailored resume right).
- **Tablet (768px – 1279px):** 8-column layout, `margin` (1.5rem / 24px) outer margin, `gutter` (1.5rem / 24px). Non-essential side panels collapse into contextual slide-overs.
- **Mobile (< 768px):** 4-column layout, `margin-sm` (1rem / 16px) outer margin, `gutter-sm` (1rem / 16px). Sidebars become full-screen modal sheets with bottom-anchored actions.

### Layout Philosophy
- Density is contextual: Application tracking lists and parsing diagnostics use tight padding (`space-xs` to `space-sm`) to optimize screen real estate.
- Strategic discovery canvases (e.g., career roadmaps, executive summary views) rely on expansive padding (`space-lg` to `space-xl`) to encourage cognitive focus.

## Elevation & Depth

Visual hierarchy uses a refined multi-layer system that pairs diffused ambient shadows with luminous structural strokes:

- **Level 0 (Base Canvas):** `#F8FAFC`. Zero elevation, pure matte surface.
- **Level 1 (Card / Table Layer):** `#FFFFFF` fill supported by a hairline border (`1px solid #E2E8F0`) and an ultra-soft ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Hover / Floating Cards):** Elevated interactives carry subtle lift: `0 10px 15px -3px rgba(15, 23, 42, 0.06), 0 4px 6px -4px rgba(15, 23, 42, 0.03)`. Border shifts slightly toward primary indigo tint (`rgba(79, 70, 229, 0.2)`).
- **Level 3 (Flyouts, Menus & Overlays):** `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.
- **Level 4 (AI Glass Surfaces):** Background fill `rgba(255, 255, 255, 0.8)` with `backdrop-filter: blur(12px)`, edged with a luminous interior border `1px solid rgba(255, 255, 255, 0.9)` and cast with an atmospheric indigo bloom: `0 12px 32px 0 rgba(99, 102, 241, 0.12)`.

## Shapes

The design system standardizes on **Rounded (Level 2)** geometry:
- Base inputs, buttons, chips, and small controls use `0.5rem` (8px) corners to balance contemporary ergonomics with enterprise discipline.
- Cards, modal containers, and dashboard modules use `rounded-lg` (`1rem` / 16px) to frame multi-tiered information.
- Hero callouts, AI generation drawers, and highlight panels use `rounded-xl` (`1.5rem` / 24px) for distinct visual focus.
- Status badges, metric counters, and avatar rings remain fully pill-shaped (`9999px`) to immediately distinguish data tags from actionable controls.

## Components

### Buttons
- **Primary:** Solid `#4F46E5` fill, `#FFFFFF` text, `0.5rem` border radius, subtle hover elevation shift, and an active scale depression of `0.985`. Focus ring: 2px offset with `rgba(79, 70, 229, 0.4)`.
- **Secondary / Outline:** `#FFFFFF` fill with `1px solid #E2E8F0` border, `#0F172A` text. On hover, background shifts to `#F8FAFC` with border transition to `#CBD5E1`.
- **AI Action Variant:** Gradient fill transitioning from `#4F46E5` to `#6366F1`, elevated with a subtle outer glow (`0 0 16px rgba(99, 102, 241, 0.3)`). Accompanied by a spark or pulse icon indicator.

### Input Fields & Text Areas
- Built on `#FFFFFF` backgrounds with `1px solid #CBD5E1` and standard `0.5rem` border radius.
- **Focus State:** Border color shifts instantly to `#4F46E5` paired with a concentric ring shadow `0 0 0 3px rgba(79, 70, 229, 0.15)`.
- **Labeling:** Text inputs display floating or persistent top labels using `label-md` in `#475569`. Error states replace borders with `#EF4444` and supply contextual helper text below.

### Cards & Panels
- White `#FFFFFF` body wrapped in a 1px border (`#E2E8F0`).
- Headers feature crisp divider borders or rely on `space-lg` separation to isolate summary statistics from tabular listings.
- Hoverable cards transition their top border highlight to `#6366F1` over a 200ms ease curve.

### Chips & AI Badges
- **Status Chips:** Pill-shaped (`9999px`), `space-xs` vertical padding, `space-sm` horizontal padding.
- **Match Metric Badge:** Light emerald background (`#ECFDF5`), bold emerald text (`#065F46`), and a 1px border (`#A7F3D0`). An embedded green dot indicates live verification status.
- **AI Token Chip:** Subtle violet-tinted container (`#EEF2FF`) with `#4338CA` typography and 1px border (`#C7D2FE`).

### Checkboxes & Radio Buttons
- 18px bounding box with `0.25rem` (4px) rounded corners for checkboxes, full circle for radios.
- Inactive state: `1.5px solid #94A3B8`.
- Checked state: `#4F46E5` background with a crisp white centered checkmark or inner dot.

### Specialized Component: Application Pipeline Stepper
- A continuous horizontal progress track running through step milestones.
- Completed stages render in `#10B981` with check icons; in-flight stages emit an ambient `#6366F1` pulse; pending stages remain neutral outline circles in `#CBD5E1`.